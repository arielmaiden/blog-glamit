<?php
    class Bootstrap extends Zend_Application_Bootstrap_Bootstrap {


        protected function _initSession(){
            Zend_Session::start();
        }

        protected function setconstants($constants) {
            foreach ($constants as $key => $value) {
                if (!defined($key)) {
                    define($key, $value);
                }
            }
        }

        protected function _initDatabase(){
            //Inicializar la base de datos para bootstrap:

            $this->bootstrap('db');             // Configuracion bootstrap de la base de datos
            $db = $this->getResource('db');     // Obtener el objeto db
            Zend_Registry::set("db", $db);      // Setear el objeto para usarlo desde cualquier lado.

       }

        protected function _initConfig() {
            // Definicion de Zend Locale
            Zend_Registry::set('config', $this->getOptions());
            $locale = new Zend_Locale('es_AR');
            Zend_Registry::set('Zend_Locale', $locale);

            date_default_timezone_set('America/Argentina/Buenos_Aires');
            setlocale(LC_TIME, "spanish");

            //para testing poder debuguear sin limite de var_dump
            if( APPLICATION_ENV !='production' ){
                ini_set('xdebug.var_display_max_depth', -1);
                ini_set('xdebug.var_display_max_children', -1);
                ini_set('xdebug.var_display_max_data', -1);
            }
        }

        protected function _initRoutes(){
            $frontController = Zend_Controller_Front::getInstance();
            $router = $frontController->getRouter();

            $router->addRoute('listado-blog', new Zend_Controller_Router_Route(
                '/blog', array(
                        'controller' => 'index',
                        'action' => 'blog'
                    )
                )
            );            
            $router->addRoute('listado-comentar-puntuar', new Zend_Controller_Router_Route(
                '/comentarpublicacion/:id', array(
                        'controller' => 'index',
                        'action' => 'comentarpublicacion',
                        'id' => null
                    )
                )
            );

        }

        /**
         * configuracion de idioma 
         */
        protected function _initTranslate() {

            $locale = new Zend_Locale('es_AR');
            try {
                // Zend Translate
                $translate = new Zend_Translate(
                        array(
                            'adapter' => 'array', // gettext
                            'content' => APPLICATION_PATH . '/../languages',
                            'locale' => $locale,
                            'scan' => Zend_Translate::LOCALE_DIRECTORY
                        )
                );
                Zend_Registry::set('Zend_Translate', $translate); // OKA
                Zend_Validate_Abstract::setDefaultTranslator($translate);
            } catch (Exception $e) {
                $description = "Clase: " . __CLASS__ . ", Método: " . __METHOD__ . ", Línea: " . __LINE__ . ". " . $e->getMessage();
                die('ERROR: Zend_Translate configuration error. [' . $description . ']');
            }
        }


        /*
        * Obtener las opciones (raiz) del menu superior.
        * Muestra solamente las opciones que tiene permitidas el usuario q se encuentra logueado.
        */
        protected function _initNavigation() {

            $this->bootstrap('layout');
            $layout = $this->getResource('layout');
            $view = $layout->getView();
            $view->ROOT_URL = ROOT_URL;

            //Inicializar la base de datos para bootstrap:
            $this->bootstrap('db'); // Bootstrap the db resource from configuration
            $db = $this->getResource('db'); // get the db object here, if necessary

            //Obtener los permisos para mostrar solo las opciones permitidas al usuario.
            $auth = Zend_Auth::getInstance();
            $identity = $auth->getIdentity();

            $view->hay_sesion = ($auth->hasIdentity() && isset($identity->email) && isset($identity->fechahora_creacion));
        }

    }