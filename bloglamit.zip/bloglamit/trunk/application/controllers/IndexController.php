<?php
    class IndexController extends Zend_Controller_Action {

        public function init() {
            $this->_helper->_layout->setLayout('layout');
        }

        public function indexAction() {
            $this->_redirect('/blog'); // ir a la pagina principal
        }

        public function blogAction(){
            $this->view->webservice = WEBSERVICE;
            $this->view->key = sha1( date('d/m/Y').'Blog' );
        }

        public function comentarpublicacionAction(){
            //Desactivar el Layout y la Vista porque es una accion para AJAX.
            $this->_helper->layout()->disableLayout();
            $this->_helper->viewRenderer->setNoRender(true);

            $id = (int) filter_var( $this->getRequest()->id ,FILTER_SANITIZE_NUMBER_INT);

            try {
                $this->view->id = $id;
                $this->renderScript('index/comentarpublicacion.phtml');

            } catch (Exception $e) {
                echo json_encode(array('status'=>false,'mensaje'=>$e->getMessage() ));                
            }
        }

        public function error($mensaje){
            $this->_helper->_layout->setLayout('layout');
            header("HTTP/1.0 404 Not Found");
            $this->view->error_code = $this->getResponse()->getHttpResponseCode(404);
            $this->view->message = $mensaje;
            $this->renderScript('errores/error.phtml');
            return;
        }
    }