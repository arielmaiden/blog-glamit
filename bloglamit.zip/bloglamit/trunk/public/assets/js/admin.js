var hostname = $(location).attr('host');
if( hostname=='localhost' || hostname=='desarrollosistemas-linuxdb-i01.minem.gob.ar' ){
    var protocol ='http://';
}else{
    var protocol = 'https://';
}
var ws_url = WS_URL+'/rest/';


var host_url = $(location).attr('pathname').substring( getPosition($(location).attr('pathname'),'/',1), $(location).attr('pathname').lastIndexOf('/') );
var site_url = protocol+hostname+host_url;

function getPosition(string, subString, index) {
   return string.split(subString, index).join(subString).length;
}


$(document).ready(function() {
    $('#Usuario').on('keypress', function(event) {
        if (event.which == 13) {
            $('#clave').focus();
        }
    });
    $('button.loginUsuarioSession').click(function(event) {
        event.preventDefault();
        var mensaje = '';
        //console.log(mensaje);
        if( $('#usuario').val()=='' ){
            mensaje+='- Debe completar su nombre Usuario.<br>';
        }
        if( $('#clave').val()=='' ){
            mensaje+='- Debe ingresar su contraseña. <br>';
        }
        if( mensaje=='' ){
            logIn();
        }else{
            $('#divError').show();
            $('#divError').html(mensaje);
        }
    });
    $('#clave').on('keypress', function(event) {
        
        if (event.which == 13) {
            var mensaje = '';
            //console.log(mensaje);
            if( $('#usuario').val()=='' ){
                mensaje+='- Debe completar su nombre de usuario.<br>';
            }
            if( $('#clave').val()=='' ){
                mensaje+='- Debe ingresar su contraseña. <br>';
            }
            if( mensaje=='' ){
                logIn();
            }else{
                $('#divError').show();
                $('#divError').html(mensaje);
            }
        }
    });

    $('#salir').click(function(event) {
        event.preventDefault();
        location.href = baseUrl+'/acceso/logout'

    });
    
});

function logIn() {

    $.post(rootpathajax+'acceso/process', $('#form_login').serialize(), function(data, textStatus, xhr) {
        if(data.status!=1 && data.status!=3){
            $('#divError').show().delay(1500).hide('slow');
        }else
        if(data.status==3){
            document.location.href = rootpathajax+'/index/mantenimiento';
        }else{
            //Login correcto
            document.location.href = rootpath+'home';
        }

    },'json');

}

var numeroALetras = (function() {

// Código basado en https://gist.github.com/alfchee/e563340276f89b22042a
    function Unidades(num){

        switch(num)
        {
            case 1: return 'UN';
            case 2: return 'DOS';
            case 3: return 'TRES';
            case 4: return 'CUATRO';
            case 5: return 'CINCO';
            case 6: return 'SEIS';
            case 7: return 'SIETE';
            case 8: return 'OCHO';
            case 9: return 'NUEVE';
        }

        return '';
    }//Unidades()

    function Decenas(num){

        let decena = Math.floor(num/10);
        let unidad = num - (decena * 10);

        switch(decena)
        {
            case 1:
                switch(unidad)
                {
                    case 0: return 'DIEZ';
                    case 1: return 'ONCE';
                    case 2: return 'DOCE';
                    case 3: return 'TRECE';
                    case 4: return 'CATORCE';
                    case 5: return 'QUINCE';
                    default: return 'DIECI' + Unidades(unidad);
                }
            case 2:
                switch(unidad)
                {
                    case 0: return 'VEINTE';
                    default: return 'VEINTI' + Unidades(unidad);
                }
            case 3: return DecenasY('TREINTA', unidad);
            case 4: return DecenasY('CUARENTA', unidad);
            case 5: return DecenasY('CINCUENTA', unidad);
            case 6: return DecenasY('SESENTA', unidad);
            case 7: return DecenasY('SETENTA', unidad);
            case 8: return DecenasY('OCHENTA', unidad);
            case 9: return DecenasY('NOVENTA', unidad);
            case 0: return Unidades(unidad);
        }
    }//Unidades()

    function DecenasY(strSin, numUnidades) {
        if (numUnidades > 0)
            return strSin + ' Y ' + Unidades(numUnidades)

        return strSin;
    }//DecenasY()

    function Centenas(num) {
        let centenas = Math.floor(num / 100);
        let decenas = num - (centenas * 100);

        switch(centenas)
        {
            case 1:
                if (decenas > 0)
                    return 'CIENTO ' + Decenas(decenas);
                return 'CIEN';
            case 2: return 'DOSCIENTOS ' + Decenas(decenas);
            case 3: return 'TRESCIENTOS ' + Decenas(decenas);
            case 4: return 'CUATROCIENTOS ' + Decenas(decenas);
            case 5: return 'QUINIENTOS ' + Decenas(decenas);
            case 6: return 'SEISCIENTOS ' + Decenas(decenas);
            case 7: return 'SETECIENTOS ' + Decenas(decenas);
            case 8: return 'OCHOCIENTOS ' + Decenas(decenas);
            case 9: return 'NOVECIENTOS ' + Decenas(decenas);
        }

        return Decenas(decenas);
    }//Centenas()

    function Seccion(num, divisor, strSingular, strPlural) {
        let cientos = Math.floor(num / divisor)
        let resto = num - (cientos * divisor)

        let letras = '';

        if (cientos > 0)
            if (cientos > 1)
                letras = Centenas(cientos) + ' ' + strPlural;
            else
                letras = strSingular;

        if (resto > 0)
            letras += '';

        return letras;
    }//Seccion()

    function Miles(num) {
        let divisor = 1000;
        let cientos = Math.floor(num / divisor)
        let resto = num - (cientos * divisor)

        let strMiles = Seccion(num, divisor, 'UN MIL', 'MIL');
        let strCentenas = Centenas(resto);

        if(strMiles == '')
            return strCentenas;

        return strMiles + ' ' + strCentenas;
    }//Miles()

    function Millones(num) {
        let divisor = 1000000;
        let cientos = Math.floor(num / divisor)
        let resto = num - (cientos * divisor)

        let strMillones = Seccion(num, divisor, 'UN MILLON DE', 'MILLONES DE');
        let strMiles = Miles(resto);

        if(strMillones == '')
            return strMiles;

        return strMillones + ' ' + strMiles;
    }//Millones()

    return function NumeroALetras(num, currency) {
        currency = currency || {};
        let data = {
            numero: num,
            enteros: Math.floor(num),
            centavos: (((Math.round(num * 100)) - (Math.floor(num) * 100))),
            letrasCentavos: '',
            letrasMonedaPlural: currency.plural || 'PESOS CHILENOS',//'PESOS', 'Dólares', 'Bolívares', 'etcs'
            letrasMonedaSingular: currency.singular || 'PESO CHILENO', //'PESO', 'Dólar', 'Bolivar', 'etc'
            letrasMonedaCentavoPlural: currency.centPlural || 'CHIQUI PESOS CHILENOS',
            letrasMonedaCentavoSingular: currency.centSingular || 'CHIQUI PESO CHILENO'
        };

        if (data.centavos > 0) {
            data.letrasCentavos = 'CON ' + (function () {
                    if (data.centavos == 1){
                        var retorno = Millones(data.centavos) + ' ' + data.letrasMonedaCentavoSingular;
                        retorno = retorno.replace(/  +/g, ' ');
                        return retorno
                    }
                    else{
                        var retorno = Millones(data.centavos) + ' ' + data.letrasMonedaCentavoPlural;
                        retorno = retorno.replace(/  +/g, ' ');
                        return retorno
                    }
                })();
        };

        if(data.enteros == 0){
            var retorno =  'CERO ' + data.letrasMonedaPlural + ' ' + data.letrasCentavos;
            retorno = retorno.replace(/  +/g, ' ');
            return retorno;
        }else
        if (data.enteros == 1){
            var retorno = Millones(data.enteros) + ' ' + data.letrasMonedaSingular + ' ' + data.letrasCentavos;
            retorno = retorno.replace(/  +/g, ' ');
            return retorno;
        }
        else{
            var retorno = Millones(data.enteros) + ' ' + data.letrasMonedaPlural + ' ' + data.letrasCentavos;
            retorno = retorno.replace(/  +/g, ' ');
            return retorno;
        }
    };

})();

/*
// Modo de uso: 500,34 USD
numeroALetras(500.34, {
    plural: 'dólares estadounidenses',
    singular: 'dólar estadounidense',
    centPlural: 'centavos',
    centSingular: 'centavo'
});
*/

function bloquearFormulario(){
    $('input, select, textarea').prop('disabled', true);
    $('#button_alta').remove();
    $('#cancel').html('Volver');
    if( $('h3').length > 0 ){
        $('h3').first().html( $('h3').first().html().replace('EDICIÓN','VISUALIZAR'));
    }
}

/* funciones para obtener rango de fechas */
Date.prototype.addDays = function(days) {
    var dat = new Date(this.valueOf())
    dat.setDate(dat.getDate() + days);
    return dat;
}

function getDates(startDate, stopDate) {
    var dateArray = new Array();
    var currentDate = startDate;
    while (currentDate <= stopDate) {
        dateArray.push(currentDate)
        currentDate = currentDate.addDays(1);
    }
    return dateArray;
}
/* ejemplo: */
/*
var dateArray = getDates(new Date(), (new Date()).addDays(2));
for (i = 0; i < dateArray.length; i ++ ) {
    alert (dateArray[i]);
}
*/