<?php
// Definir la carpeta de application.
    defined('APPLICATION_PATH') || define('APPLICATION_PATH', realpath(dirname(__FILE__) . '/../application'));

// setear el include path
    set_include_path(implode(PATH_SEPARATOR, array(
        realpath(APPLICATION_PATH . '/../library'),
        get_include_path(),
    )));


    // Definicion del entorno q se usa por default, en este ejemplo seteo por default development (APPLICATION_ENV SE DEFINE EN php.ini en cada server)

    // var_dump(dirname(__FILE__));
    if(dirname(__FILE__)=='/Applications/MAMP/htdocs/bloglamit/trunk/public'){
        define('APPLICATION_ENV','development_mac');
    }else{
        defined('APPLICATION_ENV') || define('APPLICATION_ENV', (getenv('APPLICATION_ENV') ? getenv('APPLICATION_ENV') : 'development'));
    }

    /** Zend_Application */
    require_once 'Zend/Application.php';

    // Crear application, bootstrap y ejecutar
    $application = new Zend_Application(
        APPLICATION_ENV, APPLICATION_PATH . '/configs/application.ini'
    );

    $application->bootstrap()->run();