<?php
class Controlador {
	public $_content_type = "application/json";
	private $_code = 200;
	private $_model = null;

	public function __construct() {
		$this->_model = new Modelo();
	}


	public function getpublicacionesactivas($key){
		$this->validarHash( $key );
		try {
			$res = $this->_model->getPublicacionesActivas();
			$this->response($this->json( array(
					'status'=> true,
					'registros'=> $res,
				)
			), 200);

		} catch (Exception $e) {
			$this->response($this->json( array(
					'status'=> false,
					'mensaje'=> $e->getMessage()
				)
			), 200);			
		}
	}

	public function setcomentariobyidpublicacion($key, $id_publicacion, $comentario, $puntaje){
		$this->validarHash( $key );
		try {
			$res = $this->_model->setComentarioPuntajeByIdPublicacion($id_publicacion, $comentario, $puntaje);
			$this->response($this->json( array(
					'status'=> true
				)
			), 200);

		} catch (Exception $e) {
			$this->response($this->json( array(
					'status'=> false,
					'mensaje'=> $e->getMessage()
				)
			), 200);			
		}
	}


	//FUNCIONES INTERNAS:
	/**
	 * Convertir un Json a array, validando que sea un string en formato Json.
	 */
	private function convertirJson($jsonDatos, $nombre_campo){
		if(@trim(@$jsonDatos)==''){
			return array();
		}
		if(is_array($jsonDatos)){
			return $jsonDatos;
		}else{

			$return = str_replace('\\', '', $jsonDatos);
			$return = json_decode($return,true);
			//validar que sea json:
			if($return === null){
				$this->response($this->json( array('status'=>'Failed','msg'=>'Datos incorrectos, necesariamente `'.$nombre_campo.'` es formato Json') ),400);
			}else{
				return $return;
			}
		}
	}

	private function validarHash( $key ){
		//primero validar que sea un pedido por post.
		if(!isset($_POST) || count($_POST)==0){
			$error = array (
				'status' => false,
				'mensaje' => 'Servicios solo por POST'
			);
			$this->response ( $this->json ( $error ), 401 );
		}

		$keyGenerado = sha1( date('d/m/Y').'Blog' );
		if( $key!=$keyGenerado ){
			$error = array (
				'status' => false,
				'mensaje' => 'Key incorrecta'
			);
			$this->response ( $this->json ( $error ), 401 );
		}
	}

	// funciones privadas complementarias para el retorno de datos - inicio
	private function response($data, $status) {
		echo $data;
		exit();
	}
	private function set_headers() {
		header( "HTTP/1.1 " . $this->_code . " " . $this->get_status_message() );
		header( "Content-Type:" . $this->_content_type );
	}

	private function get_status_message() {
		$status = array (
				100 => 'Continue',
				101 => 'Switching Protocols',
				200 => 'OK',
				201 => 'Created',
				202 => 'Accepted',
				203 => 'Non-Authoritative Information',
				204 => 'No Content',
				205 => 'Reset Content',
				206 => 'Partial Content',
				300 => 'Multiple Choices',
				301 => 'Moved Permanently',
				302 => 'Found',
				303 => 'See Other',
				304 => 'Not Modified',
				305 => 'Use Proxy',
				306 => '(Unused)',
				307 => 'Temporary Redirect',
				400 => 'Bad Request',
				401 => 'Unauthorized',
				402 => 'Payment Required',
				403 => 'Forbidden',
				404 => 'Not Found',
				405 => 'Method Not Allowed',
				406 => 'Not Acceptable',
				407 => 'Proxy Authentication Required',
				408 => 'Request Timeout',
				409 => 'Conflict',
				410 => 'Gone',
				411 => 'Length Required',
				412 => 'Precondition Failed',
				413 => 'Request Entity Too Large',
				414 => 'Request-URI Too Long',
				415 => 'Unsupported Media Type',
				416 => 'Requested Range Not Satisfiable',
				417 => 'Expectation Failed',
				500 => 'Internal Server Error',
				501 => 'Not Implemented',
				502 => 'Bad Gateway',
				503 => 'Service Unavailable',
				504 => 'Gateway Timeout',
				505 => 'HTTP Version Not Supported'
		);
		return ($status[$this->_code]) ? $status[$this->_code] : $status[500];
	}

	/**
	 * Generar Json por un array, si no es array retorna ''
	 *
	 * @param Array $data
	 * @return String
	 */
	private function json($data) {
        if( is_object($data)){
	        return json_encode( $data->toArray(), JSON_HEX_QUOT | JSON_HEX_TAG );
        }
        if (is_array ( $data )) {
    	    return json_encode ( $data, JSON_HEX_QUOT | JSON_HEX_TAG );
        }
        return '';
	}
	// funciones privadas complementarias para el retorno de datos - fin
}