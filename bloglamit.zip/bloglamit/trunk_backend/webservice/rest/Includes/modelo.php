<?php
class Modelo {

    private $db = null;
    public function __construct() {
        $this->db = Zend_Registry::get('db');
        try {
            $this->db->getConnection();
        } catch (Zend_Db_Adapter_Exception $e) {
            header("Content-Type:application/json");
            echo '{"status":"Failed","msg":"Datos incorrectos 1"}';
            die();
        } catch (Zend_Exception $e) {
            header("Content-Type:application/json");
            echo '{"status":"Failed","msg":"Datos incorrectos 2"}';
            die();
        }
        
        $this->db->query("SET CHARSET UTF8");
        session_commit();
    }



    public function getPublicacionesActivas(){
        $sql = "SELECT p.*, 
                        concat(u.nombre, ' ', u.apellido) as nombre_apellido,
                        (SELECT count(*) FROM usr_publicacion_comentario where id_publicacion=p.id_publicacion) as cantidad_comentarios,
                        IFNULL( (SELECT avg(puntaje) FROM usr_publicacion_puntaje where id_publicacion=p.id_publicacion),0 ) as puntaje
                FROM usr_publicacion p
                LEFT JOIN usr_usuario u on p.id_usuario = u.id_usuario
                WHERE p.estado=1
                ORDER BY p.fecha_publicacion DESC
        ";
        $res = $this->db->query($sql)->fetchAll();
        return $res;
    }

    public function setComentarioPuntajeByIdPublicacion($id_publicacion, $comentario, $puntaje){
        $sql="INSERT INTO usr_publicacion_comentario (id_publicacion, comentario) VALUES (?,?)";
        $this->db->query($sql, array($id_publicacion, $comentario));

        $sql="INSERT INTO usr_publicacion_puntaje (id_publicacion, puntaje) VALUES (?,?)";
        $this->db->query($sql, array($id_publicacion, $puntaje));
    }
}
