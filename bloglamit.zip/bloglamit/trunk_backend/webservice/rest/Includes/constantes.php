<?php
    define('JWT_SECRET_KEY', "BlogACcessKeY6587");

    //Definicion de constantes segun el server:
    switch ($_SERVER['HTTP_HOST']) {
        case 'localhost':
            define("DB_HOST","localhost");
            define("DB_NAME","bloglamit");
            define("DB_USER","root");
            define("DB_PASSWORD","");
            define("DB_SERVER", 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME);

        break;
        case 'localhost:8888':
            define("DB_HOST","localhost:8889");
            define("DB_NAME","bloglamit");
            define("DB_USER","root");
            define("DB_PASSWORD","root");
            define("DB_SERVER", 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME);
        break;
        default:
            die("HOSTNAME '" . $_SERVER['HTTP_HOST'] . "' SIN DEFINIR");
        break;
    }
    $db = Zend_Db::factory('Pdo_Mysql', array(
                'host' => DB_HOST,
                'username' => DB_USER,
                'password' => DB_PASSWORD,
                'dbname' => DB_NAME
            ));
    Zend_Registry::set('db', $db);
