<?php
	// header("Access-Control-Allow-Origin: *");
	
	require_once 'Zend/Loader/Autoloader.php';
	Zend_Loader_Autoloader::getInstance();

    require_once("../Includes/constantes.php");

    require_once("../Includes/modelo.php");
    require_once("../Includes/jwt.php");
    require_once("../Includes/controlador.php");

	$server = new Zend_Rest_Server();
	$server->setClass('Controlador');
	$server->handle();