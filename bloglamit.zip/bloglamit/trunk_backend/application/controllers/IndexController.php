<?php
    class IndexController extends Zend_Controller_Action {

        public function init() {
            $this->_helper->_layout->setLayout('layout');
        }

        public function indexAction() {
            $this->_redirect('/home'); // ir a la pagina principal
        }

        public function homeAction(){
            $oSeguridad = new Componentes_Sistema_Seguridad( $this );
            $oSeguridad->validarEstaLogueado();

            //PARA USUARIOS CONTROLLER.
            // $auth = Zend_Auth::getInstance();
            // $identidad = (array)$auth->getIdentity();
            // if( $identidad['id_rol']!=1 ){
            //     $this->_redirect('/errores/not-authorized/area/usuarios');
            // }
        }

        public function error($mensaje){
            $this->_helper->_layout->setLayout('layout');
            header("HTTP/1.0 404 Not Found");
            $this->view->error_code = $this->getResponse()->getHttpResponseCode(404);
            $this->view->message = $mensaje;
            $this->renderScript('errores/error.phtml');
            return;
        }
    }