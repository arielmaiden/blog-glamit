<?php
    class AccesoController extends Zend_Controller_Action {

        var $model;
        public function init(){
            $this->seguridad = new Componentes_Sistema_Seguridad($this);

        }

        public function loginAction(){

        }

        /**
         * Redireccion al sistema de accesos.
         */
        public function logoutAction(){

            $this->_helper->layout()->disableLayout();
            $this->_helper->viewRenderer->setNoRender(true);


            Zend_Auth::getInstance()->clearIdentity();
            Zend_Session::destroy( true );
            unset($_SESSION['Zend_Auth']['storage']);
            session_destroy();

            $this->_redirect(ROOT_URL);
        }


        /**
         * Metodo para validar la session
         */
        public function processAction() {
    
            $this->_helper->layout()->disableLayout();
            $this->_helper->viewRenderer->setNoRender(true);

            $request = $this->getRequest();

            //Sin post redireccionamos a index.
            if (!$request->isPost()) {
                echo 'Su sesión ha expirado, no tiene acceso al sistema.';
                exit();
            }

            $uname  = $request->getParam('usuario');
            $paswd = $request->getParam('clave');

            if(trim($uname)=='' || trim($paswd)==''){
                echo 'Debe ingresar "Usuario" y "Contraseña"';
                exit();
            }

            if ( $this->validarUsuarioClave($uname, $paswd) ) {
                echo json_encode(array('status'=>1)); //correcto ingreso al sistema
                exit();
            } else {
                echo json_encode(array('status'=>0)); 
                exit();
            }
        }

        public function altaAction(){

        }

        public function guardarusuarioAction(){
            $this->_helper->layout()->disableLayout();
            $this->_helper->viewRenderer->setNoRender(true);

            $o = new Application_Model_Usuario();
            $aParams = $this->getRequest()->getParams();

            try {
                if( !$o->existeUsuarioPorEmail( $aParams['email'] ) ){
                    $id_usuario = $o->guardarUsuario( $aParams );
                    $this->enviarMailConfirmacion( $id_usuario, $this->view->baseUrl() );
                    echo json_encode( array('status'=> true) );
                }else{
                    echo json_encode( array('status'=> false, 'mensaje'=> 'Ya existe un usuario registrado con ese Email') );
                }
                
            } catch (Exception $e) {
                echo json_encode( array('status'=> false, 'mensaje'=> $e->getMessage()) );
            }
        }

        private function validarUsuarioClave($uname, $paswd){

            //si no es interno validar contra la bd
            $dbAdapter = Zend_Db_Table::getDefaultAdapter();
            $authAdapter = new Zend_Auth_Adapter_DbTable($dbAdapter);
            $authAdapter->setTableName('usr_usuario')
                    ->setIdentityColumn('email')
                    ->setCredentialColumn('clave_acceso')
                    ->setCredentialTreatment("SHA1(CONCAT('".LOGIN_SEED."',?)) AND estado=1")
            ;

            $authAdapter->setIdentity($uname);
            $authAdapter->setCredential($paswd);

            // Autenticar el usuario:
            $auth = Zend_Auth::getInstance();
            $result = $auth->authenticate($authAdapter);

            if($result->isValid()){
                //obtenemos los datos de la persona logueada.
                $omitir = array('clave');
                $identity = (array)$authAdapter->getResultRowObject(null, $omitir); //campo a omitir en el zend_auth

                $result = $auth->authenticate($authAdapter);
                if ($result->isValid()) {

                    $authStorage = $auth->getStorage();
                    $authStorage->write($identity);

                    return true;
                }else{
                    return false;
                }

            }
        }

        public function mantenimientoAction() {

        }

        public function confirmarAccesoAction(){
            $o = new Application_Model_Usuario();
            $sha1 = $this->getRequest()->getParam('sha1');
            $aUsuario = $o->getUsuarioBySha1( $sha1 );

            if( !is_array($aUsuario) || count($aUsuario)==0 ){
                $this->view->correcto = false;
            }else{
                $this->view->correcto = true;
                $o->activarUsuarioById( $id_usuario );
            }
        }

        public function enviarMailConfirmacion( $id_usuario, $ruta_base ){
            $o = new Application_Model_Usuario();
            $aUsuario = $o->getUsuarioById( $id_usuario );
            $transport = new Zend_Mail_Transport_Smtp(SERVER_SMTP);

            $sha1 = sha1('confirmacion-'.$id_usuario);
            $mail = new Zend_Mail();
            $mail->addTo($aUsuario['email']);
            $mail->setSubject('Bloglamit - Registración');
            $html = '<p>BLOGLAMIT</p>';
            $html+= '<p>Se ha registrado correctamente en el blog. Para confirmar registro haga click en el siguiente link</p>';
            $html+= '<p><a href="'.$ruta_base.'/acceso/confirmar-acceso/'.$sha1.'">Confirmar </a></p>';
            $mail->setBodyHtml($html);
            $mail->setFrom('no-responder@bloglamit.com', 'no-responder');
            $mail->send($transport);

        }

        public function enviartestAction(){
            $this->_helper->layout()->disableLayout();
            $this->_helper->viewRenderer->setNoRender(true);
            /*
            $config = array(
                'auth' => 'login',
                'username' => 'arielmaiden@gmail.com',
                'password' => 'Scarlet.p00l',
                'ssl' => 'tls',
                'port' => 25
            );
            $transport = new Zend_Mail_Transport_Smtp('smtp.gmail.com', $config);
            */
            //$transport = new Zend_Mail_Transport_Smtp('localhost:8888');
            $ruta_base = 'http://localhost:8888/bloglamit/trunk_backend/public';

            $o = new Application_Model_Usuario();
            $id_usuario = $this->getRequest()->getParam('id_usuario');
            $aUsuario = $o->getUsuarioById( $id_usuario );

            $sha1 = sha1('confirmacion-'.$id_usuario);
            $mail = new Zend_Mail();
            $mail->addTo('arielmaiden@gmail.com');
            $mail->setSubject('Bloglamit - Registración');
            $html = '<p>BLOGLAMIT</p>';
            $html+= '<p>Se ha registrado correctamente en el blog. Para confirmar registro haga click en el siguiente link</p>';
            $html+= '<p><a href="'.$ruta_base.'/acceso/confirmar-acceso/'.$sha1.'">Confirmar </a></p>';
            $mail->setBodyHtml($html);
            $mail->setFrom(MAIL_FROM, 'no-responder');
            $mail->send();
            //$mail->send($transport);

        }
    }
    