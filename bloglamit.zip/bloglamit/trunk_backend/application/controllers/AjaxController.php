<?php
	class AjaxController extends Zend_Controller_Action {

		var $db=null;
		var $leyendas = array();

		public function init() {
			$this->_helper->layout()->disableLayout(); 
			$this->_helper->viewRenderer->setNoRender(true);

		}

	}