<?php 
	class usuarioController extends Zend_Controller_Action
	{

        public function init() {
            $this->_helper->_layout->setLayout('layout');

            $oSeguridad = new Componentes_Sistema_Seguridad( $this );
            $oSeguridad->validarEstaLogueado();

            $auth = Zend_Auth::getInstance();
            $identity = $auth->getIdentity();
            if( is_object($identity) ){
                $identity = (array)$identity;
            }
            if( $identity['id_rol']!=1 ){
                $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                $redirector->gotoUrl('/errores/not-authorized/1');
            }

        }

        public function indexAction(){
        	
        }

        /**
         * obtener el listado filtrao y por pagina
         */
        public function getlistadofiltradoporpaginaAction(){
            //Desactivar el Layout y la Vista porque es una accion para AJAX.
            $this->_helper->layout()->disableLayout();
            $this->_helper->viewRenderer->setNoRender(true);

            $aParams = $this->getRequest()->getParams();

            $start = $aParams['start'];
            $length = $aParams['length'];
            $filtro = $aParams['search']['value'];
            $draw = $aParams['draw'];
            $orderColumn = $aParams['columns'][ $aParams['order'][0]['column'] ]['data'];
            $orderDir = $aParams['order'][0]['dir'];


            try {
                $o = new Application_Model_Usuario();
                $res = $o->getlistadofiltradoporpagina( $filtro, $start, $length, 0, $orderColumn, $orderDir );
                $recordsTotalConFiltro = $o->getlistadofiltradoporpagina( $filtro, $start, $length, 1, $orderColumn, $orderDir );
                $recordsTotal = $o->getlistadofiltradoporpagina( $filtro, $start, $length, 2, $orderColumn, $orderDir );
                echo json_encode(
                    array('draw'=> $draw, 'recordsTotal'=> $recordsTotal['cant'], 'recordsFiltered'=> $recordsTotalConFiltro['cant'],'data'=>$res)
                );
                
            } catch (Exception $e) {
                echo json_encode(array('status'=>false,'mensaje'=>$e->getMessage() ));                
            }
        }
	}