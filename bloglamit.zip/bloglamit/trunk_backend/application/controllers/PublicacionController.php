<?php
    class PublicacionController extends Zend_Controller_Action {

        public function init() {
            $this->_helper->_layout->setLayout('layout');

            $oSeguridad = new Componentes_Sistema_Seguridad( $this );
            $oSeguridad->validarEstaLogueado();
        }

        /**
         * Se genera el listado para manejar un ABM.
         */
        public function indexAction() {

        }

        /**
         * Edicion y alta en caso que no se pase el parametro id (GET)
         * @return void
         */
        public function edicionAction() {

            $oModel = new Application_Model_Publicacion();
            if ($this->getRequest()->isPost()) {
                $form = new Application_Form_Publicacion();
                $aParams = $this->_getAllParams();

                $auth = Zend_Auth::getInstance();
                $identity = $auth->getIdentity();
                if( is_object($identity) ){
                    $identity = (array)$identity;
                }

                $aParams['id_usuario'] = $identity['id_usuario'];
                
                if ( $form->isValid($aParams) || count($form->getMessages()[''])==0 ) {
                    //Guardar los datos:
                    //convertir las fechas a formato mysql
                    $this->convertirFechasMysql($aParams); //Referencia

                    $id = $oModel->save($aParams);
                    $this->saveFiles($_FILES, $id);
                    
                    //Mostrar cartel de guardado exitoso y luego redirect
                    $form->populate($aParams);
                    $this->view->formulario = $form;

                    $this->view->guardado_exitoso = 1;
                    $this->view->guardado_redirect = '/publicacion';

                } else {
                    $id = (int) $this->getRequest()->id_publicacion;

                    $oDatos = $oModel->getPublicacionById($id);
                    if(isset($oDatos) && is_object($oDatos)){
                        $aParams = $oDatos->toArray();
                    }else{
                        $aParams = array();
                    }
                    
                    //convertir las fechas a formato normal
                    $this->convertirFechasNormal($aParams); //Referencia

                    //En caso de volver a edicion
                    $form->populate($aParams);
                    $this->view->formulario = $form;
                }
            } else {
                // Mostrar formulario para edicion
                $id = (int) $this->getRequest()->id_publicacion;

                //Obtener datos:
                $oDatos = $oModel->getPublicacionById($id);

                $this->view->registro = $oDatos;

                //Generar el form:
                $form = new Application_Form_Publicacion();
                $this->view->formulario = $form;

                if(is_object($oDatos)){
                    $oDatos = $oDatos->toArray();
                }

                if (count($oDatos) > 0) {
                    
                    $aParams = $oDatos; //Anteriormente convertido a Array.

                    //convertir las fechas a formato normal
                    $this->convertirFechasNormal($aParams); //Referencia
                    $form->populate( $aParams );
                }
            }
        }

        /**
         * baja de un item
         */
        public function eliminarAction(){

            $id = (int) filter_var( $this->getRequest()->id ,FILTER_SANITIZE_NUMBER_INT);

            //Desactivar el Layout y la Vista porque es una accion para AJAX.
            $this->_helper->layout()->disableLayout();
            $this->_helper->viewRenderer->setNoRender(true);

            $oModelrow = new Application_Model_Publicacion();
            $oModelrow->delete( $id );
        }

        /**
         * cambio de estado de un item (baja lógica)
         */
        public function cambioestadoAction(){
            $db = Zend_Registry::get('db');
            $id = (int) filter_var( $this->getRequest()->id ,FILTER_SANITIZE_NUMBER_INT);
            $estado = $this->getRequest()->estado;

            //Desactivar el Layout y la Vista porque es una accion para AJAX.
            $this->_helper->layout()->disableLayout();
            $this->_helper->viewRenderer->setNoRender(true);

            $sql="UPDATE usr_publicacion SET estado=? WHERE id_publicacion=?";
            $db->query($sql, array($estado, $id));
            echo json_encode(array('status'=>'ok'));
        }

        

        /**
         * obtener el listado filtrao y por pagina
         */
        public function getlistadofiltradoporpaginaAction(){
            //Desactivar el Layout y la Vista porque es una accion para AJAX.
            $this->_helper->layout()->disableLayout();
            $this->_helper->viewRenderer->setNoRender(true);

            $aParams = $this->getRequest()->getParams();

            $start = $aParams['start'];
            $length = $aParams['length'];
            $filtro = $aParams['search']['value'];
            $draw = $aParams['draw'];
            $orderColumn = $aParams['columns'][ $aParams['order'][0]['column'] ]['data'];
            $orderDir = $aParams['order'][0]['dir'];


            try {
                $o = new Application_Model_Publicacion();
                $res = $o->getlistadofiltradoporpagina( $filtro, $start, $length, 0, $orderColumn, $orderDir );
                $recordsTotalConFiltro = $o->getlistadofiltradoporpagina( $filtro, $start, $length, 1, $orderColumn, $orderDir );
                $recordsTotal = $o->getlistadofiltradoporpagina( $filtro, $start, $length, 2, $orderColumn, $orderDir );
                echo json_encode(
                    array('draw'=> $draw, 'recordsTotal'=> $recordsTotal['cant'], 'recordsFiltered'=> $recordsTotalConFiltro['cant'],'data'=>$res)
                );
                
            } catch (Exception $e) {
                echo json_encode(array('status'=>false,'mensaje'=>$e->getMessage() ));                
            }
        }
     

        private function saveFiles($aArchivos, $id_publicacion){
            if( isset($_FILES['imagen']['name']) ){
                $oModel = new Application_Model_Publicacion();
                
                $ext = strtolower(pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION));
                $basename = pathinfo($_FILES['imagen']['name'], PATHINFO_FILENAME);

                $nombre_amigable = $this->getUrlFriendly($basename).'-'.date('YmdHs');
                $nombre_completo = $nombre_amigable.'.'.$ext;
                $oModel->actualizarNombreArchivo($nombre_completo, $id_publicacion);

                move_uploaded_file($_FILES['imagen']['tmp_name'], UPLOAD_PATH.$nombre_completo);
            }
        }

        /**
         * Convertir todas las fechas a formato Mysql (y/m/d) para guardar en ld bd
         */
        private function convertirFechasMysql(&$aParams){
            $aCamposFecha= array('fecha_publicacion');
            foreach ($aCamposFecha as $v) {
                if(isset($aParams[$v]) && trim($aParams[$v])!=''){
                    $f = new Zend_Date($aParams[$v], 'dd/MM/yyyy');
                    $f = $f->toString("Y-MM-dd");
                    $aParams[$v]=$f;
                }
            }
        }
        /**
         * Convertir todas las fechas a formato normal (d/m/y) para el form de edicion
         */
        private function convertirFechasNormal(&$aParams){
            $aCamposFecha= array('fecha_publicacion');
            foreach ($aCamposFecha as $v) {
                if(isset($aParams[$v]) && trim($aParams[$v])!=''){
                    $f = new Zend_Date($aParams[$v], 'dd/MM/yyyy');
                    $f = $f->toString("dd/MM/Y");
                    $aParams[$v]=$f;
                }
            }
        }

        /**
         * Crear url Amigable
         */
        private function getUrlFriendly($str, $options=array()) {
            $friendlyURL = htmlentities($str, ENT_COMPAT, "UTF-8", false);

            //Reemplazo latin
            $friendlyURL = preg_replace('/&([a-z]{1,2})(?:acute|lig|grave|ring|tilde|uml|cedil|caron);/i','\1',$friendlyURL);

            //convertir simbolos
            $friendlyURL = html_entity_decode($friendlyURL,ENT_COMPAT, "UTF-8");

            //reemplazar todo lo que no sea alfanumerico
            $friendlyURL = preg_replace('/[^a-z0-9-]+/i', '-', $friendlyURL);

            //Remover simbolos +- extras
            $friendlyURL = preg_replace('/-+/', '-', $friendlyURL);

            //Remover - consecutivos
            $friendlyURL = trim($friendlyURL, '-');

            //minusculas
            $friendlyURL = strtolower($friendlyURL);
            return $friendlyURL;
        }
    }