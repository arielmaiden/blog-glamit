<?php
	//Db table:
    class Application_Model_DbTable_Publicacion extends Zend_Db_Table_Abstract {
        protected $_name = 'usr_publicacion';
        protected $_primary = 'id_publicacion';
        protected $_rowClass = 'Application_Model_DbRow_Publicacion';
        protected $_dependentTables = array();
        protected $_referenceMap = array();
    }

    class Application_Model_DbRow_Publicacion extends Zend_Db_Table_Row_Abstract {
    }

