<?php
	class Application_Model_Usuario
	{
 
        public function getlistadofiltradoporpagina( $filtro, $start, $length, $getCantidad, $orderColumn, $orderDir ){
            $db = Zend_Registry::get('db');
            if( $getCantidad==1 || $getCantidad==2 ){
                $select = " count(*) as cant";
                $limit = '';
                $orderBy = '';
            }else{
                $select = "u.id_usuario,
                           r.nombre as nombre_rol,
                           u.email,
                           u.nombre,
                           u.apellido,
                           u.email
                        ";
                if( $length!=-1 ){
                    $limit = "LIMIT {$start},{$length}";
                }else{
                    $limit = "";
                }
                $orderBy = "ORDER BY {$orderColumn} {$orderDir}";
            }

            $sql="SELECT {$select}
                FROM usr_usuario as u
                LEFT JOIN ref_rol r ON u.id_rol = r.id_rol
                WHERE (
                        u.nombre LIKE ? OR 
                        u.apellido LIKE ? 
                    )
                {$orderBy}
                {$limit}
            ";
            $aParams = array();
            if( $getCantidad==2 ){
                $filtro = ''; //para obtener el total sin filtro
            }
            for ($i=0; $i<2 ; $i++) { 
                $aParams[]="%{$filtro}%";
            }

            if( $getCantidad==0 ){
                $res = $db->query($sql, $aParams)->fetchAll();
            }else{
                $res = $db->query($sql, $aParams)->fetch();
            }
            return $res;
        }

        public function existeUsuarioPorEmail( $email ){
            $db = Zend_Registry::get('db');
            $sql = "SELECT count(*) cant FROM usr_usuario WHERE email = ?";
            $r = $db->query($sql, array($email))->fetch();
            return $r['cant'] >0;
        }

        public function getUsuarioById( $id_usuario ){
            $db = Zend_Registry::get('db');
            $sql = "SELECT * FROM usr_usuario WHERE id_usuario = ?";
            return $db->query($sql, array($id_usuario))->fetch();
        }

        public function getUsuarioBySha1( $sha1 ){
            $db = Zend_Registry::get('db');
            $sql = "SELECT * FROM usr_usuario WHERE SHA1(CONCAT('confirmacion-',id_usuario)) = ? AND estado=0";
            return $db->query($sql, array($sha1))->fetch();;
        }

        public function guardarUsuario($aDatos){
            $db = Zend_Registry::get('db');
            $sql="INSERT INTO usr_usuario (id_rol, clave_acceso, estado, nombre, apellido, email) VALUES (2, ?, 0, ?, ?, ?)";
            $clavesha1 = sha1(LOGIN_SEED.$aDatos['password']);
            $db->query($sql, array($clavesha1, $aDatos['nombre'], $aDatos['apellido'], $aDatos['email']));

            $sql="SELECT id_usuario FROM usr_usuario ORDER BY id_usuario DESC LIMIT 1";
            $lastInsertId = $db->query($sql)->fetch()['id_usuario'];
            return $lastInsertId;
        }

	}