<?php
    class Application_Model_Publicacion extends Application_Model_DbTable_Publicacion {

        var $_table = NULL;
        var $_pk = 'id_publicacion';
        var $_info = NULL;

        function __construct($config = array()) {
            parent::__construct($config);

            $this->_table = new Application_Model_DbTable_Publicacion();
            $i = $this->info();
            $this->_info = $i['cols'];
            $this->_metadata = $i['metadata'];
        }

//      FUNCIONES PARA ALMACENAR DATOS - Inicio
        private function filtrarColumnas(&$values) {
            foreach ($values as $k => $v) {
                if (!in_array($k, $this->_info)) {
                    unset($values[$k]);
                }
            }
        }


        private function anularEnterosVacios(&$values){
            $aDataTypeStr = array('varchar','char','text','blob','longblob','longtext','int');
            foreach ($this->_metadata as $campo => $metadata) {
                if( !in_array($metadata['DATA_TYPE'], $aDataTypeStr) && is_string($values[$campo]) && trim($values[$campo])=='' ){
                    $values[$campo] = NULL;
                }
            }
        }

        /**
         * Insert / update
         * @param Array $values
         * @return Integer
         */
        public function save($values) {
            //Filtramos los campos del form, para intentar hacer update de valores
            //como submit (no pertenecientes a la tabla)
            $this->filtrarColumnas($values);
            $this->anularEnterosVacios($values);

            // Validar insert o update
            if (!isset($values[$this->_pk]) || $values[$this->_pk] == '') {
                $row = $this->_table->createRow();
                $row->setFromArray($values);
                $row->save();
                $array = $row->toArray();
                return $array[$this->_pk];
            } else {
                $where = $this->_table->getAdapter()->quoteInto($this->_pk . ' = ?', $values[$this->_pk]);
                $this->_table->update($values, $where);
                return $values[$this->_pk];
            }
        }

        /**
         * Borrar un registro
         * @param Integer $id
         * @return boolean
         */
        public function delete($id) {
            $rs = $this->_table->find($id);
            if (count($rs) > 0) {
                $row = $rs->current();
                $row->delete();
                return true;
            } else {
                return false;
            }
        }
//      FUNCIONES PARA ALMACENAR DATOS - Fin


        /**
         * Obtener los datos de un registro por Id
         */
        public function getPublicacionById($id) {
            $select = $this->_table
                    ->select('usr_publicacion.*')
                    ->where('usr_publicacion.id_publicacion=?', $id)
                    ->setIntegrityCheck(false)
            ;
            return $this->_table->fetchRow($select);
        }

        /**
         * Obtener todos los registros.
         */
        public function getAll() {
            $select = $this->_table
                    ->select('usr_publicacion.*')
                    ->order('id_publicacion DESC')
                    ->setIntegrityCheck(false)
            ;
            return $this->_table->fetchAll($select)->toArray();
        }

        /**
         * Obtener todos los registros. 
         * Con sus campos relacionales.
         */
        public function getAllWithFieldsRelated() {
            $db = Zend_Registry::get('db');
            $sql = "SELECT t1.*  ,t2.id_usuario as nombre
				    FROM usr_publicacion as t1
                    LEFT JOIN usr_usuario t2 ON t1.id_usuario = t2.nombre
				    ORDER BY t1.id_publicacion
            ";
            return $db->query($sql)->fetchAll();
        }

        


        public function getlistadofiltradoporpagina( $filtro, $start, $length, $getCantidad, $orderColumn, $orderDir ){
            $db = Zend_Registry::get('db');
            if( $getCantidad==1 || $getCantidad==2 ){
                $select = " count(*) as cant";
                $limit = '';
                $orderBy = '';
            }else{
                $select = "p.id_publicacion,
                           concat(u.nombre,' ',u.apellido) as nombre_apellido,
                           p.cuerpo,
                           p.titulo,
                           p.fecha_publicacion,
                           p.estado,
                           u.id_usuario
                        ";
                if( $length!=-1 ){
                    $limit = "LIMIT {$start},{$length}";
                }else{
                    $limit = "";
                }
                $orderBy = "ORDER BY {$orderColumn} {$orderDir}";
            }

            $sql="SELECT {$select}
                FROM usr_publicacion as p
                LEFT JOIN usr_usuario u ON p.id_usuario = u.id_usuario
                WHERE (
                        p.cuerpo LIKE ? OR 
                        p.fecha_publicacion LIKE ?
                    )
                {$orderBy}
                {$limit}
            ";
            $aParams = array();
            if( $getCantidad==2 ){
                $filtro = ''; //para obtener el total sin filtro
            }
            for ($i=0; $i<2 ; $i++) { 
                $aParams[]="%{$filtro}%";
            }

            if( $getCantidad==0 ){
                $res = $db->query($sql, $aParams)->fetchAll();
            }else{
                $res = $db->query($sql, $aParams)->fetch();
            }
            return $res;
        }

        public function actualizarNombreArchivo($nombre_amigable, $id_publicacion){
            $db = Zend_Registry::get('db');
            $sql="UPDATE usr_publicacion SET imagen = ? WHERE id_publicacion = ?";
            $db->query($sql, array($nombre_amigable, $id_publicacion));
        }
    }
