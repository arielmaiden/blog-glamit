<?php
class Application_Form_Publicacion extends Zend_Form
{
    public function init(){

        $this->setIsArray(true);
        $this->setAttrib('enctype', 'multipart/form-data');

        $this->setDecorators(array(
            array('ViewScript', array('viewScript' => 'forms/publicacion.phtml')),
            'Form'
        ));

        //Tell all of our form elements to render only itself and the label
        $this->setElementDecorators(
          array(
            'ViewHelper',
            'Label',
            'Errors'
          )
        );

        $this->addElement("hidden","id_publicacion");
		$this->addElement("text", "titulo", array(
			"placeholder"   => "Texto",
			"class"         => "form-control",
			"required"		=> true
		));

        $this->addElement("textarea", "cuerpo", array(
            "placeholder"   => "Texto",
            "class"         => "form-control",
            "required"      => true,
            "rows"          => 4
        ));

		$this->addElement("file", "imagen", array(
			"class"         => "form-control",
			"required"		=> false,
            "accept"        => "image/*"
		));
        $this->imagen->setDestination(UPLOAD_PATH);

		$this->addElement("text", "fecha_publicacion", array(
			"placeholder"   => "dd/mm/yyyy",
			"class"         => "form-control date",
			"data-date-format" => "dd/mm/yyyy",
			"required"		=> true
		));


        $this->addElement("select", "estado", array(
            "class"         => "form-control",
            "required"      => false,
            "value"         => 1
        ));
        $this->estado->addMultiOption("","Seleccione una de las opciones");
        $this->estado->addMultiOption("1","Activa");
        $this->estado->addMultiOption("2","Inactiva");


        //Boton submit:
        $boton = new Zend_Form_Element_Button('button_alta',
                        array('label' => 'Guardar',
                            'type' => 'submit',
                            'escape' => false,
                            'required' => false,
                            'ignore' => false
                        )
        );
        $this->addElement($boton);
    }
}