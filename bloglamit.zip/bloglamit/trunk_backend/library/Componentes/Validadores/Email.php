<?php
	/**
	 * Validar el formato de una dirección de correo.
	 */
	class Componentes_Validadores_Email extends Zend_Validate_Abstract
	{
	    const MSG_INVALID = "'%value%' no es una dirección de correo válida.";

	    /** @var Zend_Validate_EmailAddress */
	    protected static $_validatorEmailAddress;

	    /** @var array */
	    protected $_messageTemplates = array();

	    /**
	     *
	     * @return Zend_Validate_EmailAddress
	     */
	    public static function getValidatorEmailAddress()
	    {
	        if (is_null(self::$_validatorEmailAddress)) {
	            self::$_validatorEmailAddress = new Zend_Validate_EmailAddress();
	        }
	        return self::$_validatorEmailAddress;
	    }

	    /**
	     *
	     * @param string $value
	     * @return boolean
	     */
	    public function isValid($value)
	    {
	        $valid = true;
	        if (!self::getValidatorEmailAddress()->isValid($value)) {
	            $this->_messageTemplates[$value] = self::MSG_INVALID;
	            $this->_error($value, $value);
	            $valid = false;
	        }
	        return $valid;
	    }
	}