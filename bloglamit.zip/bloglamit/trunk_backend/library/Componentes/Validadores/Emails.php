<?php
	/**
	 * Validar multiples direcciones de correo con separadores utilizando el validador 'Email'
	 */
	class Componentes_Validadores_Emails extends Componentes_Validadores_Email
	{
	    /**
	     * Valores ya normalizados previamente de separadores (, ;) y espacios
	     *
	     * @param string $value
	     * @return boolean
	     */
	    public function isValid($value)
	    {
	        $valid = true;
	        $emails = explode(', ', $value);
	        foreach ($emails as $email) {
	            if (!parent::isValid($email)) {
	                $valid = false;
	            }
	        }
	        return $valid;
	    }
	}