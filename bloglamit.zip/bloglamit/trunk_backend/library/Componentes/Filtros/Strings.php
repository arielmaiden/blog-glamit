<?php 
	abstract class Componentes_Filtros_Strings implements Zend_Filter_Interface{

	    public static function comaespacios($value){
	        // normalize delimiters
	        $value = str_replace(array(' ', ';'), ',', $value);
	        // explode values
	        $values = explode(',', $value);
	        // remove empty values
	        $values = array_filter($values);
	        // implode
	        $value = implode(', ', $values);
	        // return filtered value
	        return $value;
	    }



		public static function custom_number_format($n, $precision = 3) {
		    if ($n < 1000000) {
		        // Anything less than a million
		        $n_format = number_format($n).' kwh';
		    } else if ($n < 1000000000) {
		        // Anything less than a billion
		        $n_format = number_format($n / 1000000, $precision) .' mwh';
		    } else {
		        // At least a billion
		        $n_format = number_format($n / 1000000000, $precision) . 'gwh';
		    }

		    return $n_format;
		}
	}