<?php
class Componentes_Sistema_Seguridad {

    public function __construct( $class ){
        $this->class = $class;
    }

    /**
     * Se valida la sesion. 
     * Se puede retornar un booleano o si se envia bloqueo en true se redirecciona al home  
     * @param bool $bloqueo: bloquear el acceso y redireccionar a una pagina o solo retornar false.
     * @return bool|null
     */
    public function validarLogin($bloqueo=false){

        // validar si esta logueado:
        $auth = Zend_Auth::getInstance();
        $identidad = (array)$auth->getIdentity();
        if (!$auth->hasIdentity() || !isset($identidad['fechahora_creacion'])) {

            if(!$bloqueo){
                return false;
            }else{
                $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                $redirector->gotoUrl('/errores/not-authorized/1');
            }
        }
        return true;
    }


    public function crearJwt($identity){
        $aToken = (array)$identity; //Los datos personales relevantes de la persona.
        return Componentes_Sistema_Jwt::encode($aToken, JWT_SECRET_KEY);
    }

    public function decodificarJwt($jwt){
        return Componentes_Sistema_Jwt::decode($jwt, JWT_SECRET_KEY, array('HS256'));
    }


    public function validarEstaLogueado(){
        // validar si esta logueado:
        $auth = Zend_Auth::getInstance();
        if (!$auth->hasIdentity()) {
            $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
            $redirector->gotoUrl('/login');
        }else{
            $identity = (array)$auth->getIdentity();
            if( !isset($identity['fechahora_creacion']) ){
                $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                $redirector->gotoUrl('/login');
            }
        }
    }
}